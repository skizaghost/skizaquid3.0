<slot />

<style>
	main {
		display: grid;
		grid-template-rows: auto 1fr;
		min-height: 100vh;
	}

	nav {
		padding: 0.2rem;
	}

	h1 {
		font-size: 1rem;
		color: var(--primary);
	}
</style>
