import type { RequestHandler } from '@sveltejs/kit';
import fs from 'fs';

export const GET: RequestHandler = async ({ params }) => {
	const file_name = (params as any)['slug'];
	const file = fs.readFileSync(`./media/${file_name}`);
	return new Response(file);
};
