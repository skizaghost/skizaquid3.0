import { db } from '$lib';
import { type Actions, redirect } from '@sveltejs/kit';
import type { RequestEvent } from './$types';
import bycrypt from 'bcrypt';

const salt = 10;

async function hash_password(password: string) {
	const hash = await bycrypt.hash(password, salt);
	return hash;
}

export const actions = {
	default: async (event) => {
		const body = await event.request.formData();

		const full_name = body.get('name');
		if (typeof full_name !== 'string') {
			return {
				success: false
			};
		}

		const email = body.get('email_address');
		if (typeof email !== 'string') {
			return { success: false };
		}

		const password = body.get('password');
		const confirm_password = body.get('confirm_password');

		console.log(body);

		if (typeof password !== 'string') {
			console.log('Password field failed');
			return { success: false };
		}

		if (typeof confirm_password !== 'string') {
			console.log('Confirm password field failed');
			return { success: false };
		}

		if (password !== confirm_password) {
			console.log('Username and password not equal');
			return { success: false };
		}

		const phone_number = body.get('phone_number');
		if (typeof phone_number !== 'string') {
			console.log('Failed in phone number');
			return { success: false };
		}

		const result = await db.user.create({
			data: {
				email,
				is_admin: false,
				password: await hash_password(password),
				phone_number: phone_number,
				name: full_name,
				is_client: true
			}
		});

		console.log(result);

		event.cookies.set('user_id', result.id.toString());
		throw redirect(301, '/dash');
	}
} satisfies Actions;
