<main>
	<form method="POST">
		<h2>Welcome to skizaquid</h2>
		<div class="form-container">
			<input type="text" name="name" placeholder="Full Name" required />
			<input type="text" name="email_address" placeholder="Email Address" required />
			<input type="text" name="phone_number" placeholder="Phone Number" required />
			<input type="password" name="password" placeholder="Password" required />
			<input type="password" name="confirm_password" placeholder="Confirm Password" required />
		</div>
		<input type="submit" value={'Create Account'} class="primary-button" />
		<a href="/login" class="text-button">Already have an account?</a>
	</form>
</main>

<style>
	main {
		display: flex;
		align-items: center;
		justify-content: center;
		height: 100vh;
	}

	h2 {
		font-weight: 500;
		font-size: 1.2rem;
	}

	.form-container {
		display: flex;
		flex-direction: column;
		gap: 8pt;
		width: 100%;
		margin-bottom: 1rem;
	}

	.primary-button {
		width: 100%;
	}

	form {
		width: 300pt;
		display: flex;
		flex-direction: column;
		align-items: center;
		gap: 8pt;
		background-color: white;
		padding: 16pt;
		border: 1pt solid var(--surface-variant);
		border-radius: 8pt;
	}
</style>
