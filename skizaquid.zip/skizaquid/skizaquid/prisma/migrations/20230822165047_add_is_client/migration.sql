-- AlterTable
ALTER TABLE "User" ADD COLUMN     "is_client" BOOLEAN NOT NULL DEFAULT true;
