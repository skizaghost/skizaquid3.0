-- AlterTable
ALTER TABLE "AudioScript" ADD COLUMN     "title" TEXT NOT NULL DEFAULT '';
