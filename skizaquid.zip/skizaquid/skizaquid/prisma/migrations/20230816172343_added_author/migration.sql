-- AlterTable
ALTER TABLE "AudioFile" ADD COLUMN     "author" TEXT NOT NULL DEFAULT '';
