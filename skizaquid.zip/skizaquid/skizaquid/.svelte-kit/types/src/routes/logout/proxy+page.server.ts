// @ts-nocheck
import type { PageServerLoad } from './$types';

export const load = async (event: Parameters<PageServerLoad>[0]) => {
	const user_id = event.cookies.get('user_id');

	if (user_id === undefined) {
		return {
			success: true
		};
	}
	event.cookies.delete('user_id');
	return {
		success: true
	};
};
