// @ts-nocheck
import type { PageServerLoad } from './$types';

export const load = (event: Parameters<PageServerLoad>[0]) => {
	const user_id = event.cookies.get('user_id');

	return {
		is_logged_in: user_id !== undefined
	};
};
